import React from "react";

const PageOne = () => {
  return (
    <div className="">
      <div className="pageone">
        <div>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad debitis
          numquam repellat optio hic illum fuga eaque consequatur, consequuntur
          eius iusto, corporis ut ipsam cumque adipisci a excepturi voluptas
          maiores?
        </div>
      </div>
    </div>
  );
};

export default PageOne;
