import React from 'react'

const Fejl = () => {
  return (
    <div>Fejl</div>
  )
}

export default Fejl