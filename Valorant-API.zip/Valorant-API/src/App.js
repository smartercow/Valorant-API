import './App.scss';
import "./Styles/Agents.scss";
import './Styles/Loading.scss'
import Loading from './Components/Loading'

import Home from './Components/Home';
function App() {
  return (
    <div className="App">
      {/* <Loading /> */}
      <Home />
    </div>
  );
}

export default App;
